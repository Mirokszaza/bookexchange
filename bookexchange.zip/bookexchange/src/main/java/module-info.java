module com.miroks.bookexchange {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;

    opens com.miroks.bookexchange to javafx.fxml;
    opens com.miroks.bookexchange.fxcontrollers to javafx.fxml;
    opens com.miroks.bookexchange.models to org.hibernate.orm.core, jakarta.persistence;

    exports com.miroks.bookexchange;
    exports com.miroks.bookexchange.fxcontrollers;
}
