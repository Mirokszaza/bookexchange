package com.miroks.bookexchange.models;

import com.miroks.bookexchange.models.enums.PublicationStatus;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("BOOK")
public class Book extends Publication {

    private String isbn;
    private Double price;

    // Default constructor required by JPA
    public Book() {
        super();
    }

    // Parameterized constructor
    public Book(String title, String author, PublicationStatus status, String category, User owner,
                String isbn, Double price) {
        super(title, author, status, category, owner);
        this.isbn = isbn;
        this.price = price;
    }

    // Getters and Setters

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
