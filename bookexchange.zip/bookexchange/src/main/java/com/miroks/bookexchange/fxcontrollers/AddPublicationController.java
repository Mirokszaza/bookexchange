package com.miroks.bookexchange.fxcontrollers;

import com.miroks.bookexchange.models.Book;
import com.miroks.bookexchange.models.enums.PublicationStatus;
import com.miroks.bookexchange.models.User;
import com.miroks.bookexchange.services.PublicationService;
import com.miroks.bookexchange.utils.JavaFXUtils;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;

import java.time.LocalDate;

public class AddPublicationController {

    @FXML
    private TextField titleField;

    @FXML
    private TextField authorField;

    @FXML
    private TextField categoryField;

    @FXML
    private TextField isbnField;

    @FXML
    private TextField priceField;

    // Simulated logged-in user; in a full application, this would come from your authentication logic.
    private User loggedInUser = null; // You can set this to a dummy user for now.

    // Create an instance of PublicationService to handle saving data.
    private PublicationService publicationService = new PublicationService();

    @FXML
    public void handleSubmit(ActionEvent event) {
        try {
            String title = titleField.getText();
            String author = authorField.getText();
            String category = categoryField.getText();
            String isbn = isbnField.getText();
            double price = Double.parseDouble(priceField.getText());

            // Create a new Book object. For now, the owner is loggedInUser (which might be null during testing).
            Book newBook = new Book(title, author, PublicationStatus.AVAILABLE, category, loggedInUser, isbn, price);

            // Save the new book to the database.
            publicationService.savePublication(newBook);

            JavaFXUtils.showInfoAlert("Success", "Publication added successfully!");

            // Optionally, clear the input fields here.
            titleField.clear();
            authorField.clear();
            categoryField.clear();
            isbnField.clear();
            priceField.clear();
        } catch (Exception e) {
            JavaFXUtils.showErrorAlert("Error", "Failed to add publication: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
