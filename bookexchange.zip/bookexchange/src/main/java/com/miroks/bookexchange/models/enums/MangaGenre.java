package com.miroks.bookexchange.models.enums;

public enum MangaGenre {
    SHONEN,
    SHOJO,
    SEINEN,
    JOSEI,
    ISEKAI,
    SPORTS,
    SLICE_OF_LIFE,
    FANTASY,
    HORROR,
    ACTION,
    DRAMA,
    COMEDY
}
