package com.miroks.bookexchange.fxcontrollers;

import com.miroks.bookexchange.models.Publication;
import com.miroks.bookexchange.services.PublicationService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class MainWindow {

    @FXML
    private TableView<Publication> publicationTable;

    @FXML
    private TableColumn<Publication, String> titleColumn;

    @FXML
    private TableColumn<Publication, String> authorColumn;

    @FXML
    private TableColumn<Publication, String> statusColumn;

    @FXML
    private TableColumn<Publication, String> categoryColumn;

    private PublicationService publicationService = new PublicationService();

    @FXML
    public void initialize() {
        // Set up the columns to use properties from the Publication class.
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));

        // Load the publications data.
        refreshTable();
    }

    public void refreshTable() {
        List<Publication> publications = publicationService.getAllPublications();
        ObservableList<Publication> data = FXCollections.observableArrayList(publications);
        publicationTable.setItems(data);

    }
}
