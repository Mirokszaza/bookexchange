package com.miroks.bookexchange.fxcontrollers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private void onLoginButtonClick(ActionEvent event) {
        try {
            // Load main window FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/miroks/bookexchange/main-window.fxml"));
            Parent root = loader.load();

            // Set the new scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Book Exchange - Main Window");
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
