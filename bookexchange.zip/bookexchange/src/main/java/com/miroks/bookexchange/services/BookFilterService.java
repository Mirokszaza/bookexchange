package com.miroks.bookexchange.services;

import com.miroks.bookexchange.models.Publication;
import java.util.List;
import java.util.stream.Collectors;

public class BookFilterService {

    // In a real application, this might come from a database.
    // For demonstration, we'll use an in-memory list of publications.
    private List<Publication> publications;

    // Constructor that initializes the service with a list of publications.
    public BookFilterService(List<Publication> publications) {
        this.publications = publications;
    }

    // Filter publications by a given category.
    public List<Publication> filterByCategory(String category) {
        return publications.stream()
                .filter(pub -> pub.getCategory() != null && pub.getCategory().equalsIgnoreCase(category))
                .collect(Collectors.toList());
    }

    // Filter publications by a given author.
    public List<Publication> filterByAuthor(String author) {
        return publications.stream()
                .filter(pub -> pub.getAuthor() != null && pub.getAuthor().equalsIgnoreCase(author))
                .collect(Collectors.toList());
    }

    // Retrieve a publication by its ID.
    public Publication getPublication(Long id) {
        return publications.stream()
                .filter(pub -> pub.getId() != null && pub.getId().equals(id))
                .findFirst().orElse(null);
    }

    // Update a publication in the list.
    public void updatePublication(Publication updatedPublication) {
        for (int i = 0; i < publications.size(); i++) {
            if (publications.get(i).getId().equals(updatedPublication.getId())) {
                publications.set(i, updatedPublication);
                break;
            }
        }
    }
}
