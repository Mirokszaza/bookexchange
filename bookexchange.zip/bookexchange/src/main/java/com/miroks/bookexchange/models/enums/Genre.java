package com.miroks.bookexchange.models.enums;

public enum Genre {
    FICTION,
    NON_FICTION,
    SCIENCE,
    HISTORY,
    FANTASY,
    BIOGRAPHY,
    EDUCATION,
    SELF_HELP,
    ROMANCE,
    TECHNOLOGY,
    OTHER
}
