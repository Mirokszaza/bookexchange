package com.miroks.bookexchange.services;

import com.miroks.bookexchange.models.BookTransaction;
import com.miroks.bookexchange.models.Publication;
import com.miroks.bookexchange.models.User;
import java.util.List;

public class StatisticsService {

    private List<Publication> publications;
    private List<User> users;
    private List<BookTransaction> transactions;

    // Constructor to initialize the service with data
    public StatisticsService(List<Publication> publications, List<User> users, List<BookTransaction> transactions) {
        this.publications = publications;
        this.users = users;
        this.transactions = transactions;
    }

    // Method to get basic publication statistics
    public String getBookStats() {
        return "Total Publications: " + publications.size();
    }

    // Method to get basic user statistics
    public String getUserStats() {
        return "Total Users: " + users.size();
    }

    // Method to get basic transaction statistics
    public String getTransactionStats() {
        return "Total Transactions: " + transactions.size();
    }
}
