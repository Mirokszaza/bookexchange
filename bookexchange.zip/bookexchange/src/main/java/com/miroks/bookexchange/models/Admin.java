package com.miroks.bookexchange.models;

import com.miroks.bookexchange.models.enums.Role;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "admins")
public class Admin extends User {

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "employment_date")
    private LocalDate employmentDate;

    // Default constructor required by JPA
    public Admin() {
        super();
    }

    // Parameterized constructor for Admin
    public Admin(String login, String password, String email, String firstName, String surname,
                 String phoneNumber, LocalDate employmentDate) {
        // Call the parent constructor and set the role to ADMIN
        super(login, password, email, firstName, surname, Role.ADMIN);
        this.phoneNumber = phoneNumber;
        this.employmentDate = employmentDate;
    }

    // Getters and Setters

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public LocalDate getEmploymentDate() {
        return employmentDate;
    }

    public void setEmploymentDate(LocalDate employmentDate) {
        this.employmentDate = employmentDate;
    }

    // Implement abstract methods from User

    @Override
    public boolean login(String login, String password) {
        // For now, a simple check that compares the credentials
        return this.getLogin().equals(login) && this.getPassword().equals(password);
    }

    @Override
    public void logout() {
        // Print a simple message for logout
        System.out.println("Admin " + getLogin() + " has logged out.");
    }

    @Override
    public void register() {
        // Admins don't typically register through the system.
        // You can leave this empty or print a message.
        System.out.println("Admin registration is not allowed. Please use pre-configured credentials.");
    }
}
