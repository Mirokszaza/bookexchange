package com.miroks.bookexchange.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "comments")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 1000)
    private String content;

    @Column(nullable = false)
    private LocalDateTime timestamp;

    // The user who wrote the comment
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User author;

    // The publication this comment is about
    @ManyToOne
    @JoinColumn(name = "publication_id", nullable = false)
    private Publication publication;

    // Self-referencing for nested comments (a comment can have replies)
    @ManyToOne
    @JoinColumn(name = "parent_comment_id")
    private Comment parentComment;

    // One comment can have many replies
    @OneToMany(mappedBy = "parentComment")
    private List<Comment> replies;

    // Default constructor required by JPA
    public Comment() {
    }

    // Parameterized constructor
    public Comment(String content, LocalDateTime timestamp, User author, Publication publication, Comment parentComment) {
        this.content = content;
        this.timestamp = timestamp;
        this.author = author;
        this.publication = publication;
        this.parentComment = parentComment;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public Publication getPublication() {
        return publication;
    }

    public void setPublication(Publication publication) {
        this.publication = publication;
    }

    public Comment getParentComment() {
        return parentComment;
    }

    public void setParentComment(Comment parentComment) {
        this.parentComment = parentComment;
    }

    public List<Comment> getReplies() {
        return replies;
    }

    public void setReplies(List<Comment> replies) {
        this.replies = replies;
    }
}
