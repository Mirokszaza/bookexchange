package com.miroks.bookexchange.test;

import com.miroks.bookexchange.services.PaymentService;
import java.time.LocalDateTime;

public class TestPaymentService {
    public static void main(String[] args) {
        PaymentService paymentService = new PaymentService();

        // Test processing a payment
        boolean paymentResult = paymentService.processPayment(1L, 2L, 3L, 49.99);
        System.out.println("Payment result: " + paymentResult);

        // Test refunding a payment
        boolean refundResult = paymentService.refundPayment(100L);
        System.out.println("Refund result: " + refundResult);
    }
}
