package com.miroks.bookexchange.services;

import com.miroks.bookexchange.models.Comment;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CommentService {

    // In a real application, comments would be stored in a database.
    // For now, we'll use an in-memory list to simulate storing comments.
    private List<Comment> comments;

    public CommentService() {
        // Initialize the in-memory list
        this.comments = new ArrayList<>();
    }

    /**
     * Adds a new comment.
     *
     * @param comment the Comment object to add
     */
    public void addComment(Comment comment) {
        comments.add(comment);
        System.out.println("Comment added: " + comment.getContent());
    }

    /**
     * Retrieves all comments for a specific publication.
     *
     * @param publicationId the ID of the publication
     * @return a list of comments for that publication
     */
    public List<Comment> getCommentsByPublication(Long publicationId) {
        return comments.stream()
                .filter(c -> c.getPublication() != null && c.getPublication().getId().equals(publicationId))
                .collect(Collectors.toList());
    }

    /**
     * Retrieves all comments.
     *
     * @return a list of all comments
     */
    public List<Comment> getAllComments() {
        return new ArrayList<>(comments);
    }
}
