package com.miroks.bookexchange.models.enums;

public enum PublicationStatus {
    AVAILABLE,
    BORROWED,
    RESERVED,
    SOLD
}
