package com.miroks.bookexchange.models;

import com.miroks.bookexchange.models.enums.Role;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "clients")
public class Client extends User {

    @Column(name = "birth_date")
    private LocalDate birthdate;

    // Using ElementCollection to store a list of addresses as strings.
    @ElementCollection
    @CollectionTable(name = "client_addresses", joinColumns = @JoinColumn(name = "client_id"))
    @Column(name = "address")
    private List<String> addresses;

    // Default constructor required by JPA
    public Client() {
        super();
    }

    // Parameterized constructor
    public Client(String login, String password, String email, String firstName, String surname,
                  LocalDate birthdate, List<String> addresses) {
        // We set the role to USER automatically for clients
        super(login, password, email, firstName, surname, Role.USER);
        this.birthdate = birthdate;
        this.addresses = addresses;
    }

    // Getters and Setters

    public LocalDate getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(LocalDate birthdate) {
        this.birthdate = birthdate;
    }

    public List<String> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<String> addresses) {
        this.addresses = addresses;
    }

    // Implementing abstract methods from User

    @Override
    public boolean login(String login, String password) {
        // Simple implementation: compare credentials
        // In a real app, you'd compare hashed passwords, etc.
        return this.getLogin().equals(login) && this.getPassword().equals(password);
    }

    @Override
    public void logout() {
        // Simple implementation for now
        System.out.println("Client " + getLogin() + " has logged out.");
    }

    @Override
    public void register() {
        // Registration logic can be added here; for now, a simple print statement
        System.out.println("Client " + getLogin() + " is registering.");
    }
}
