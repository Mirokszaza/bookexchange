package com.miroks.bookexchange.models;

import com.miroks.bookexchange.models.enums.PublicationStatus;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("MANGA")
public class Manga extends Publication {

    private String mangaGenre; // Could be an enum if needed

    // Default constructor
    public Manga() {
        super();
    }

    // Parameterized constructor
    public Manga(String title, String author, PublicationStatus status, String category, User owner,
                 String mangaGenre) {
        super(title, author, status, category, owner);
        this.mangaGenre = mangaGenre;
    }

    // Getters and Setters
    public String getMangaGenre() {
        return mangaGenre;
    }

    public void setMangaGenre(String mangaGenre) {
        this.mangaGenre = mangaGenre;
    }
}
