package com.miroks.bookexchange.jdbcsolution;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtils {

    // H2 Database connection details
    private static final String URL = "jdbc:h2:~/bookexchange;DB_CLOSE_ON_EXIT=FALSE";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    /**
     * Get a connection to the H2 database.
     *
     * @return a Connection object
     * @throws SQLException if connection fails
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
