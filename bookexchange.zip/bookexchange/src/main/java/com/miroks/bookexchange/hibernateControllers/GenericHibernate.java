package com.miroks.bookexchange.hibernateControllers;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class GenericHibernate {

    private static EntityManagerFactory emf;

    static {
        // "bookExchangePU" is the name in your persistence.xml
        emf = Persistence.createEntityManagerFactory("bookExchangePU");
    }

    public static EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public static <T> void saveEntity(T entity) {
        EntityManager em = getEntityManager();
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
        em.close();
    }

    public static <T> T findEntity(Class<T> clazz, Object primaryKey) {
        EntityManager em = getEntityManager();
        T entity = em.find(clazz, primaryKey);
        em.close();
        return entity;
    }

    // Add update, delete, etc. as needed
}
