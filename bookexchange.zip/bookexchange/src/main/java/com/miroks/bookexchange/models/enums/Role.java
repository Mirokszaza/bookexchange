package com.miroks.bookexchange.models.enums;

public enum Role {
    ADMIN,
    USER
}
