package com.miroks.bookexchange.services;

import com.miroks.bookexchange.hibernateControllers.GenericHibernate;
import com.miroks.bookexchange.models.Publication;
import jakarta.persistence.EntityManager;

import java.util.List;

public class PublicationService {

    // Save a new publication (Book, Manga, etc.) to the database.
    public void savePublication(Publication publication) {
        EntityManager em = GenericHibernate.getEntityManager();
        em.getTransaction().begin();
        em.persist(publication);
        em.getTransaction().commit();
        em.close();
    }

    // Retrieve all publications from the database.
    public List<Publication> getAllPublications() {
        EntityManager em = GenericHibernate.getEntityManager();
        List<Publication> publications = em.createQuery("SELECT p FROM Publication p", Publication.class)
                .getResultList();
        em.close();
        return publications;
    }
}
